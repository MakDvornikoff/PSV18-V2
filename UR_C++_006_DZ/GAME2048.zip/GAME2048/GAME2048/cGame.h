#pragma once
#include "cTable.h"

class cGame
{
#define GEN_NEW_NUMBER pTable->SetInFreeCell(int(rand() % pTable->GetCountFreeCells()+1),int (((rand() % 1000+1) < 909) ? 2 : 4));
	cTable * pTable;
	void Show();

public:
	cGame(int SizeRow, int SizeColumn);
	~cGame();
	void Start();
};

