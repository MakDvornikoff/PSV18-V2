#include "stdafx.h"
#include "cGame.h"
#include <iostream>
#include <conio.h>
#include "windows.h"
using namespace std;



cGame::cGame(int SizeRow, int SizeColumn)
{
	pTable = new cTable(SizeRow, SizeColumn);
	GEN_NEW_NUMBER;
	Show();
}

cGame::~cGame()
{
	if (pTable != NULL) delete pTable;
}

void cGame::Start()
{
#define UP 72
#define DOWN 80
#define LEFT 75
#define RIGHT 77
#define ESC 27

	if (pTable == NULL) return;
	int  button = 0;
	bool isChangedTable = false;
	while (button != ESC && pTable->GetCountFreeCells() != 0) {

		button = _getch();


		switch (button) {
		case UP: {
			isChangedTable = pTable->PushUp();
			break;
		}
		case DOWN: {
			isChangedTable = pTable->PushDown();
			break;
		}
		case LEFT: {
			isChangedTable = pTable->PushLeft();
			break;
		}
		case RIGHT: {
			isChangedTable = pTable->PusRight();
			break;
		}
		}

		if (isChangedTable) {
			Show();
			GEN_NEW_NUMBER;
			Show();
			isChangedTable = false;
		}



	}
	cout << "\n  ===  End Game  ===\n\n";
	cout << "Press <ENTER> to continue...\n";
	while (_getch() != 13);
}

void cGame::Show()
{
	system("cls");
	cout << "TOTAL SCORE = " << pTable->GetSum() << "\n\n";
	pTable->Show();
}


