#include "stdafx.h"
#include "cTable.h"
#include <iostream>
using namespace std;

inline void cTable::Bubble(int & Cell1, int & Cell2)
{
	int tmp = Cell1;
	Cell1 = Cell2;
	Cell2 = tmp;
}



cTable::cTable(int SizeRow, int SizeColumn) : SizeRow(SizeRow), SizeColumn(SizeColumn), MaxCountCells(SizeRow*SizeColumn)
{
	pCells = (int**)malloc(SizeRow * sizeof(int*));
	for (int i = 0; i < SizeRow; ++i) {
		*(pCells + i) = (int*)malloc(SizeColumn * sizeof(int));
		for (int j = 0; j < SizeColumn; ++j)
			*(*(pCells + i) + j) = 0;
	}
	CountFreeCells = MaxCountCells;
	SumValueInCells = 0;
}

cTable::~cTable()
{
	if (pCells != NULL) free(pCells);
}

bool cTable::PushUp()
{
	bool isChanged = false;
	int idst, isrc;
	for (int j = 0; j < SizeColumn; ++j) {
		idst = isrc = 0;
		while (isrc < SizeRow-1) {
			++isrc;
			if (Cell(isrc, j) == 0) continue;
			if (Cell(idst, j) == 0) {
				isChanged = true;
				Bubble(Cell(idst, j), Cell(isrc, j));
				continue;
			}
			if (Cell(idst, j) == Cell(isrc, j)) {
				isChanged = true;
				SumAndUnion(Cell(idst, j), Cell(isrc, j));
			}			
			if ((isrc - idst) > 1) --isrc;
			++idst;

		}
	}
	return isChanged;
}

bool cTable::PushDown()
{
	bool isChanged=false;
	int idst, isrc;
	for (int j = 0; j < SizeColumn; ++j) {
		idst = isrc = SizeRow - 1;
		while (isrc > 0) {
			--isrc;
			if (Cell(isrc, j) == 0) continue;
			if (Cell(idst, j) == 0) {
				isChanged = true;
				Bubble(Cell(idst, j), Cell(isrc, j));
				continue;
			}
			if (Cell(idst, j) == Cell(isrc, j)) {
				isChanged = true;
				SumAndUnion(Cell(idst, j), Cell(isrc, j));
			}
			if ((idst - isrc) > 1) ++isrc;
			--idst;
		}
	}
	return isChanged;
}

bool cTable::PushLeft()
{
	bool isChanged = false;
	int idst, isrc;
	for (int i = 0; i < SizeRow; ++i) {
		idst = isrc = 0;
		while (isrc < SizeColumn - 1) {
			++isrc;
			if (Cell(i,isrc) == 0) continue;
			if (Cell(i,idst) == 0) {
				isChanged = true;
				Bubble(Cell(i,idst), Cell(i,isrc));
				continue;
			}
			if (Cell(i,idst) == Cell(i,isrc)) {
				isChanged = true;
				SumAndUnion(Cell(i,idst), Cell(i,isrc));
			}
			if ((isrc - idst) > 1) --isrc;
			++idst;

		}
	}
	return isChanged;
}

bool cTable::PusRight()
{
	bool isChanged = false;
	int idst, isrc;
	for (int i = 0; i < SizeRow; ++i) {
		idst = isrc = SizeColumn-1;
		while (isrc >0) {
			--isrc;
			if (Cell(i, isrc) == 0) continue;
			if (Cell(i, idst) == 0) {
				isChanged = true;
				Bubble(Cell(i, idst), Cell(i, isrc));
				continue;
			}
			if (Cell(i, idst) == Cell(i, isrc)) {
				isChanged = true;
				SumAndUnion(Cell(i, idst), Cell(i, isrc));
			}
			if ((idst-isrc) > 1) ++isrc;
			--idst;

		}
	}
	return isChanged;
}

void cTable::SumAndUnion(int & Destination, int & CellToNull)
{
	Destination += CellToNull;
	CellToNull = 0;
	++CountFreeCells;
}

const int & cTable::GetCountFreeCells()
{
	return CountFreeCells;
}

void cTable::SetInFreeCell(int NumInFreeSpace, int Value)
{
	if (NumInFreeSpace > CountFreeCells) {
		cout << "������ : ����� �������� ��������." << NumInFreeSpace << " > " << CountFreeCells;
		return;
	}

	int count = 0;
	for (int i = 0; i < SizeRow; ++i)
		for (int j = 0; j < SizeColumn; ++j) {
			if (*(*(pCells + i) + j) == 0)
				++count;
			if (count == NumInFreeSpace) {
				*(*(pCells + i) + j) = Value;
				SumValueInCells += Value;
				--CountFreeCells;
				return;
			}
		}
}

int cTable::GetSum()
{
	return SumValueInCells;
}

void cTable::Show()
{
#define line {for(int cc=0;cc<SizeColumn;++cc)cout<<"--------";cout<<"-\n";}
	line;
	for (int i = 0; i < SizeRow; ++i) {
		for (int j = 0; j < SizeColumn; ++j) {
			if (*(*(pCells + i) + j) != 0)
				cout << "|  " << *(*(pCells + i) + j) << "\t";
			else
				cout << "|      \t";
		}
		cout << "|" << endl;
		line;
	}
}

