#pragma once



class cTable
{
	const int SizeRow;
	const int SizeColumn;
	const int MaxCountCells;

	int CountFreeCells;
	int SumValueInCells;

	int ** pCells=NULL;
	inline void Bubble(int & Cell1, int & Cell2);
	#define Cell(ROW,COLUMN) (*(*(pCells + ROW) + COLUMN))
public:
	cTable(int SizeRow, int SizeColumn);
	~cTable();

	bool PushUp();
	bool PushDown();
	bool PushLeft();
	bool PusRight();

	void SumAndUnion(int & Destination, int & CellToNull);

	const int & GetCountFreeCells();
	void SetInFreeCell(int NumInFreeSpace, int Value);
	int GetSum();
	void Show();
};

