#include "stdafx.h"
#include "cFuelOffice.h"
#include <iostream>
using namespace std;

cFuelOffice::cFuelOffice()
{
}

cFuelOffice::cFuelOffice(int Password) : password(Password)
{
}

void cFuelOffice::AddFuelStation(cFuelStation * FuelStation)
{
	++CountStation;
	if (pFuelStations == NULL)
		pFuelStations = (cFuelStation**)malloc(sizeof(cFuelStation*));
	else
		pFuelStations = (cFuelStation**)realloc(pFuelStations, CountStation * sizeof(cFuelStation*));

	CheckNull(pFuelStations);
	if (isNull) {
		CountStation = 0;
		return;
	}

	/*cFuelStation* p;
	p= new cFuelStation(FuelStation);*/
	//*(pFuelStations + CountStation - 1) = &FuelStation; 
	*(pFuelStations+CountStation-1) = FuelStation;

	
}

cFuelStation & cFuelOffice::FuelStation(int number)
{
	if (number<1 || number>CountStation) {
		cout << "ERROR: �� ������������ ����� �������";
		cFuelStation * pNULL = NULL;
		return *pNULL;
	}

	return **(pFuelStations + number - 1);
}

void cFuelOffice::PrintAllFuelStations()
{
	for (int i = 0; i < CountStation; ++i)
		cout << **(pFuelStations + i);
}

void cFuelOffice::GetCash(int PasswordStation, int NumFuelStation, int AmountMoney)
{
	if (NumFuelStation < 1 || NumFuelStation > CountStation) {
		cout << "ERROR : �������� ����� �������.";
		return;
	}
	CashBox += (**(pFuelStations + NumFuelStation -1)).GetCash(PasswordStation, NumFuelStation, AmountMoney);
}








ostream & operator<<(ostream & stream, cFuelOffice & FuelOffice)
{
	cout << "\n********************************\n";
	cout << "���� :";
	cout << "���������� ������� : "<< FuelOffice.CountStation<<endl;
	cout << "CashBox : " << FuelOffice.CashBox << " ���.\n";
	cout << "********************************\n";
	
	return stream;
}
