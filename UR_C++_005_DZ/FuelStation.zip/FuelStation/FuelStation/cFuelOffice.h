#pragma once
#include "cFuelStation.h"

class cFuelOffice
{
	int password;
	int CashBox;
	cFuelStation ** pFuelStations=NULL;
	int CountStation = 0;
public:
	cFuelOffice();
	cFuelOffice(int Password);
	void AddFuelStation(cFuelStation * FuelStation);

	cFuelStation & FuelStation(int number);
	void PrintAllFuelStations();
	friend ostream & operator <<(ostream & stream,  cFuelOffice & FuelOffice);
	void GetCash(int Password, int NumFuelStation,int AmountMoney);
};

