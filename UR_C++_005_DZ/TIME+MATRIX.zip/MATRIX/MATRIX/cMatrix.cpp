#include "stdafx.h"
#include "cMatrix.h"




cMatrix::cMatrix()
{

}
void cMatrix::Create(int & Rows, int & Columns)
{
	//==== ��������� ������ =====
	SizeRows = Rows;
	SizeColumns = Columns;

	arr = (MyType**)malloc(SizeRows * sizeof(MyType*));

	CheckNull(arr);
	if (isNull) {
		SizeRows = 0;
		SizeColumns = 0;
		return;
	}

	for (int i = 0; i < SizeRows; i++) {
		*(arr + i) = (MyType*)malloc(SizeColumns * sizeof(MyType));

		CheckNull(arr);
		if (isNull) {
			free(arr);
			SizeRows = 0;
			SizeColumns = 0;
			return;
		}

	}
}

cMatrix::cMatrix(int Rows, int Columns, TFilling Filling)
{
	Create(Rows, Columns);
//==== ���������� ������� ====
	if (Filling == None) return;

	for (int i = 0; i < SizeRows; i++) 
	for (int j = 0; j < SizeColumns; j++)
		switch (Filling) {
		case Zero: {
			*(*(arr + i) + j) = 0;
			break;
		}
		case Rnd:
			*(*(arr + i) + j) = RND;
		}
}

void cMatrix::CopyFrom(cMatrix & Matrix)
{
	Create(Matrix.SizeRows, Matrix.SizeColumns);

	for (int i = 0; i < SizeRows; ++i)
		for (int j = 0; j < SizeColumns; ++j)
			*(*(arr + i) + j) = *(*(Matrix.arr + i) + j);
}
cMatrix::cMatrix(cMatrix & Matrix)
{
	CopyFrom(Matrix);
}

cMatrix & cMatrix::operator=(cMatrix & Matrix)
{
	if (&Matrix == this) return *this;
	if (arr != NULL) free(arr);
	CopyFrom(Matrix);	
	return *this;
}
cMatrix::~cMatrix()
{
	if (arr != NULL) free(arr);
}


cMatrix & cMatrix::AddSub(cMatrix &  M1, cMatrix &  M2, TChoi�eAddSub Choi�eAddSub)
{
	cMatrix * mres = NULL;
	if (M1.SizeRows != M2.SizeRows || M1.SizeColumns != M2.SizeColumns) {
		cout << "ERROR: " << ((Choi�eAddSub == Add) ? "��������" : "���������") << " ������ ����������.";
		return*mres;
	}
	mres = new cMatrix(M1.SizeRows, M2.SizeColumns, None);
	for (int i = 0; i < M1.SizeRows; ++i)
		for (int j = 0; j < M2.SizeColumns; ++j)
			*(*(mres->arr + i) + j) = *(*(M1.arr + i) + j) + *(*(M2.arr + i) + j)*Choi�eAddSub;
	return *mres;
}

cMatrix & cMatrix::operator+(cMatrix &  Matrix)
{
	return AddSub(*this, Matrix, Add);
}
cMatrix & cMatrix::operator-(cMatrix &  Matrix)
{
	return AddSub(*this, Matrix, Sub);
}

cMatrix & cMatrix::operator*(cMatrix &  Matrix)
{
	cMatrix * mres = NULL;
	if (SizeColumns != Matrix.SizeRows) {
		cout << "ERROR: ��������� ������ ����������.";
		return *mres;
	}
	mres = new cMatrix(SizeRows, SizeColumns, None);
	for (int i = 0; i < SizeRows; ++i)
		for (int j = 0; j < Matrix.SizeColumns; ++j) {
			int sum = 0;
			for (int r = 0; r < SizeColumns; ++r)
				sum += *(*(arr + i) + r) + *(*(Matrix.arr + r) + j);
			*(*(mres->arr + i) + j) = sum;
		}
	return *mres;
}


MyType & cMatrix::operator()(int  Row, int  Column)
{
	MyType * elem=NULL;
	if (Row >= SizeRows || Column >= SizeColumns) {
		msgerrbound;
		elem = (MyType*)malloc(sizeof(MyType));
		*elem = 0;
	}
	else elem = *(arr + Row) + Column;
	return  *elem;
}


cMatrix & cMatrix::Transp( )
{
	{
		cMatrix * mres = new cMatrix(SizeColumns, SizeRows, None);
		if (mres == NULL) return *mres;
		for (int i = 0; i < mres->SizeRows; ++i)
			for (int j = 0; j < mres->SizeColumns; ++j)
				*(*(mres->arr + i) + j) = *(*(arr + j) + i);
		return *mres;
	}
}





ostream & operator << (ostream & stream, cMatrix & m) {
	for (int i = 0; i < m.SizeRows; ++i) {
		for (int j = 0; j < m.SizeColumns; ++j)
			cout << "  " << *(*(m.arr + i) + j) << "\t";
		cout << endl;
	}
	return stream;
}