#include "stdafx.h"
#include "cMatrix.h"


cMatrix::cMatrix()
{
}

cMatrix::cMatrix(int Rows, int Columns)
{
	SizeRows = Rows;
	SizeColumns = Columns;
	arr = (MyType**)malloc(SizeRows * sizeof(MyType*));
	cmpmem(arr);
	if (err) {
		SizeRows = 0;
		SizeColumns = 0;
		return;
	}

	for (int i = 0; i < SizeRows; i++) {
		*(arr + i) = (MyType*)malloc(SizeColumns * sizeof(MyType));
		cmpmem(arr);
		if (err) {
			SizeRows = i;
			return;
		}
		for (int j = 0; j < SizeColumns; j++)
			*(*(arr + i) + j) = RND;
	}
}


cMatrix::~cMatrix()
{
}


ostream & operator << (ostream & stream, cMatrix m) {
	for (int i = 0; i < m.SizeRows; i++) {
		for (int j = 0; j < m.SizeColumns; j++)
			cout << "  " << *(*(m.arr + i) + j) << "\t";
		cout << endl;
	}
	return stream;
}