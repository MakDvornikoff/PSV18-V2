

#include "cTime.h"
#include <iostream>

using namespace std;
// ================  ������������  =============
cTime::cTime()
{
	Hours = 0;
	Minutes = 0;
	Time12 = false;
}
cTime::cTime(const sTime & t) {
	//cTime *tres = new cTime;
	Hours = t.Hours;
	Minutes = t.Minutes;
	Time12 = t.Time12;
}

cTime::cTime( char * ch)
{
	int carry = 0;
	StrToTime(*this, ch, carry);
}

// ================  Private �������   =============
void cTime::align(cTime & t, int&  carry) {
	while (t.Minutes >= 60) {
		++(t.Hours);
		t.Minutes -= 60;
	}
	while (t.Minutes < 0) {
		--(t.Hours);
		t.Minutes += 60;
	}
	while (t.Hours >= 24) {
		++carry;
		t.Hours -= 24;
	}
	while (t.Hours < 0) {
		--carry;
		t.Hours += 24;
	}
}
void cTime::StrToTime(cTime& t, char * p, int&  carry) {
	char *c;
	unsigned long int n = 1;
	unsigned long int k = 0;
	int pm = 0;

	c = strchr(p, 'p');
	if (c == NULL) c = strchr(p, 'P');
	if (c == NULL)
		c = strchr(p, 'a');
	if (c == NULL)c = strchr(p, 'A');

	else pm = 1;
	if (c == NULL) {
		t.Time12 = false;
		c = strchr(p, 0);
	}
	else t.Time12 = true;

	while (n<MaxUnsignedLongIntN && c >= p) {
		--c;
		if (*c >= '0'&&*c <= '9') {
			k += (*c - 48)*n;
			n *= 10;
		}
	}

	t.Minutes = k % 100;
	t.Hours = k / 100;

	if (t.Hours <= 12 && pm)
		t.Hours = t.Hours + 12;

	cTime::align(t, carry);

}
cTime& cTime::Add(const cTime& t1, const cTime& t2, int&  carry) {
	//cTime *t = (cTime*)malloc(sizeof(cTime));
	cTime *t = new cTime;
	t->Minutes = t1.Minutes + t2.Minutes;
	t->Hours = t1.Hours + t2.Hours;
	cTime::align(*t, carry);
	return *t;
}
cTime& cTime::Sub(const cTime& t1, const cTime& t2, int&  carry) {
	//cTime *t = (cTime*)malloc(sizeof(cTime));
	cTime *t = new cTime;
	t->Minutes = t1.Minutes - t2.Minutes;
	t->Hours = t1.Hours - t2.Hours;
	cTime::align(*t, carry);
	return *t;
}

// ================  Public �������   =============

void cTime::set24() {
	Time12 = false;
}
void cTime::set12() {
	Time12 = true;
}

void cTime::operator()(char * ch)
{
	int carry = 0;
	StrToTime(*this, ch, carry);
}

// ================  ���������� ����������   =============
bool const cTime::operator<(const cTime & t)
{
	int carry = 0;
	cTime *tres = &cTime::Sub(*this, t, carry);
	return (carry<0)?true:false;
}
bool const cTime::operator>(const cTime & t)
{
	int carry = 0;
	cTime *tres = &cTime::Sub( t, *this, carry);
	return (carry<0) ? true : false;
	return false;
}
bool  const cTime::operator==(const cTime & t)
{
	return (Hours==t.Hours&&Minutes==t.Minutes);
}
cTime &  cTime::operator+(const cTime & t)
{
	int carry = 0;
	cTime *tres = &cTime::Add(*this,t,carry);
	return *tres;
}
cTime &  cTime::operator-(const cTime & t)
{
	int carry = 0;
	cTime *tres = &cTime::Sub(*this, t, carry);
	return *tres;
}
void cTime::operator = (const cTime & t) {
	Hours = t.Hours;
	Minutes = t.Minutes;
	Time12 = t.Time12;
}
ostream &  operator<<(ostream & stream, const cTime & t)
{
	char * p = NULL;
	sTime::TimeToString(t, p);
	cout << p << endl;
	free(p);
	return stream;
}

//Cin ��������� ��������� ������� �����:
// 13:35=13:35  13:35am= 1:35pm   13:35pm= 1:35pm  
// 75 = 1:15    75a = 1:15am      75p = 1:15pm
//  3600=12:00  3600a=12:00a      3600p=12:00am
// 3675=13:15   3675a= 1:15pm	  3675p= 1:15pm
// ENTER = 0:00
// carry ����� ������������ ��� ����������� ���������� ���� (���� �����24� ����������� � ����� - align())
istream & operator>>(istream & stream, cTime & t)
{
	char * p = (char*)malloc(MaxLengthCinTime * sizeof(char));
	gets_s(p, MaxLengthCinTime);
	int carry = 0;
	cTime::StrToTime(t,p,carry);
	
	cout << " = ";
	if (carry) cout << carry << " days ";
	cout <<  t;
	free(p);
	return stream;
}
